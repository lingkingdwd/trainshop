package com.trainshop.dao;

import com.trainshop.common.IOperations;
import com.trainshop.model.Category;

public interface ICategoryDao extends IOperations<Category>{
	
}
