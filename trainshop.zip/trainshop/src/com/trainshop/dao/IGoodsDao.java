package com.trainshop.dao;

import com.trainshop.common.IOperations;
import com.trainshop.model.Goods;

public interface IGoodsDao extends IOperations<Goods>{
	
}
