(function($)
{

	$("#shop-featured-1").owlCarousel({
      	slideSpeed : 300,
      	paginationSpeed : 400,
      	singleItem:true
	});

})(jQuery);